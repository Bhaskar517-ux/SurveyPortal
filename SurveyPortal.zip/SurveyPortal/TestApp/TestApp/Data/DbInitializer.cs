﻿/*using System.Collections.Generic;
using System.Linq;
using TestApp.Models;

namespace TestApp.Data
{
    public static class DbInitializer
    {
        public static void SeedTestData(ApplicationDbContext context)
        {
            // Check if there are any questions already in the database
            if (!context.Questions.Any())
            {
                // Create sample questions and options
                var question1 = new Question
                {
                    Text = "What is your favorite color?",
                    Options = new List<Option>
                    {
                        new Option { Text = "Red" },
                        new Option { Text = "Blue" },
                        new Option { Text = "Green" }
                    }
                };

                var question2 = new Question
                {
                    Text = "What is your favorite animal?",
                    Options = new List<Option>
                    {
                        new Option { Text = "Cat" },
                        new Option { Text = "Dog" },
                        new Option { Text = "Bird" }
                    }
                };

                // Add the questions to the context and save changes
                context.Questions.AddRange(question1, question2);
                context.SaveChanges();
            }
        }
    }
}
*/
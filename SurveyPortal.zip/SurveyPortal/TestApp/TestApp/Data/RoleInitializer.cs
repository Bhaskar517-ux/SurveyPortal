﻿/*using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Threading.Tasks;
using TestApp.Areas.Identity.Data;

public class RoleInitializer
{
    public static async Task SeedRoles(IServiceProvider serviceProvider)
    {
        var roleManager = serviceProvider.GetRequiredService<RoleManager<IdentityRole>>();
        var userManager = serviceProvider.GetRequiredService<UserManager<TestAppUser>>();

        string adminRole = "Admin";
        string userRole = "User";

        // Create roles if they don't exist
        if (!await roleManager.RoleExistsAsync(adminRole))
        {
            await roleManager.CreateAsync(new IdentityRole(adminRole));
        }
        if (!await roleManager.RoleExistsAsync(userRole))
        {
            await roleManager.CreateAsync(new IdentityRole(userRole));
        }

        // Create an admin user if it doesn't exist
        string adminEmail = "admin@example.com"; // Change to your desired admin email
        var adminUser = await userManager.FindByEmailAsync(adminEmail);
        if (adminUser == null)
        {
            adminUser = new TestAppUser { UserName = adminEmail, Email = adminEmail };
            await userManager.CreateAsync(adminUser, "Admin@1234"); // Set a strong password
            await userManager.AddToRoleAsync(adminUser, adminRole);
        }

        // Create a test user if it doesn't exist
        string userEmail = "user@example.com"; // Change to your desired user email
        var user = await userManager.FindByEmailAsync(userEmail);
        if (user == null)
        {
            user = new TestAppUser { UserName = userEmail, Email = userEmail };
            await userManager.CreateAsync(user, "User@1234"); // Set a strong password
            await userManager.AddToRoleAsync(user, userRole);
        }
    }
}
*/
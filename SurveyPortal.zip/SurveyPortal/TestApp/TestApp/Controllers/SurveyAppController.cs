﻿
/*using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TestApp.Data;
using TestApp.Models;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

//[Authorize(Roles = "Admin")]
public class SurveyAppController : Controller
{
    private readonly ApplicationDbContext _context;

    public SurveyAppController(ApplicationDbContext context)
    {
        _context = context;
    }

    *//*public IActionResult AdminOnlyAction()
    {
        // Only accessible to users with Admin role
        return View();
    }*//*
    // GET: SurveyApp/Dashboard
    public IActionResult Dashboard()
    {
        return View(); // Ensure this returns the correct view
    }


    [HttpGet]
    public async Task<IActionResult> Index()
    {
        var questions = await _context.Questions
            .Include(q => q.Options) // Include options when retrieving questions
            .ToListAsync();

        return View(questions); // Pass the list of questions to the view
    }
    // GET: SurveyApp/Create
    [HttpGet]
    public IActionResult Create()
    {
        return View(); // Show the create question form
    }
    
    [HttpPost]
    public async Task<IActionResult> Create(Question question, string[] options)
    {
        if (ModelState.IsValid)
        {
            // Loop through options and create Option instances
            foreach (var optionText in options)
            {
                if (!string.IsNullOrWhiteSpace(optionText))
                {
                    var option = new Option { Text = optionText };
                    question.Options.Add(option); // Add option to the question
                }
            }

            // Save the question with its options to the database
            _context.Questions.Add(question);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index"); // Redirect to the questions list after saving
        }

        return View(question); // If validation fails, return to the same view
    }


    // GET: SurveyApp/Edit/5
    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var question = await _context.Questions
            .Include(q => q.Options)
            .FirstOrDefaultAsync(m => m.Id == id);

        if (question == null)
        {
            return NotFound();
        }

        return View(question);
    }

    // POST: SurveyApp/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Question question, string[] options)
    {
        if (id != question.Id)
        {
            return NotFound();
        }

        if (ModelState.IsValid)
        {
            // Update options
            question.Options.Clear();
            foreach (var optionText in options)
            {
                if (!string.IsNullOrWhiteSpace(optionText))
                {
                    var option = new Option { Text = optionText };
                    question.Options.Add(option);
                }
            }

            try
            {
                _context.Update(question);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!QuestionExists(question.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return RedirectToAction("Index");
        }

        return View(question);
    }
    private bool QuestionExists(int id)
    {
        return _context.Questions.Any(q => q.Id == id);
    }


    // GET: SurveyApp/Delete/5
    [HttpGet]
    public async Task<IActionResult> Delete(int id)
    {
        var question = await _context.Questions
            .Include(q => q.Options)
            .FirstOrDefaultAsync(m => m.Id == id);

        if (question == null)
        {
            return NotFound();
        }

        return View(question);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var question = await _context.Questions
            .Include(q => q.Options)
            .FirstOrDefaultAsync(q => q.Id == id);

        if (question != null)
        {
            // Remove associated options before deleting the question
            _context.Options.RemoveRange(question.Options);
            _context.Questions.Remove(question);
            await _context.SaveChangesAsync();
        }

        return RedirectToAction("Index");
    }



    // Action method for viewing all submissions by users
    public async Task<IActionResult> ViewSubmissions()
    {
        var submissions = await _context.Answers
            .Include(a => a.Question)
            .Include(a => a.Option)
            .ToListAsync();

        return View(submissions); // Pass the list of submissions to the view
    }


    // Method to fetch responses for admin dashboard
    // View all responses from users
    [HttpGet]
    public async Task<IActionResult> ViewResponses()
    {
        var responses = await _context.Responses.ToListAsync();
        return View(responses);
    }

    [HttpGet]
    public IActionResult ResponsesChart()
    {
        // Assuming you have a method to get the responses from the database
        var responses = _context.Responses.ToList(); // Fetch the responses
        return View(responses);
    }

}*/
/*using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using TestApp.Data;
using TestApp.Models;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using TestApp.Areas.Identity.Data;
using TestApp.Constants;

[Authorize]
public class SurveyAppController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<TestAppUser> _userManager;

    public SurveyAppController(ApplicationDbContext context, UserManager<TestAppUser> userManager)
    {
        _context = context;
        _userManager = userManager;
    }

    // GET: SurveyApp/Dashboard
    public IActionResult Dashboard()
    {
        return View(); // Ensure this returns the correct view
    }

    [HttpGet]
    [Authorize(Permissions.SurveyApp.View)] // Check permission
    public async Task<IActionResult> Index()
    {
        var questions = await _context.Questions
            .Include(q => q.Options) // Include options when retrieving questions
            .ToListAsync();

        return View(questions); // Pass the list of questions to the view
    }

    // GET: SurveyApp/Create
    [HttpGet]
    [Authorize(Permissions.SurveyApp.Create)] // Check permission
    public IActionResult Create()
    {
        return View(); // Show the create question form
    }

    [HttpPost]
    [Authorize(Permissions.SurveyApp.Create)] // Check permission
    public async Task<IActionResult> Create(Question question, string[] options)
    {
        if (ModelState.IsValid)
        {
            foreach (var optionText in options)
            {
                if (!string.IsNullOrWhiteSpace(optionText))
                {
                    var option = new Option { Text = optionText };
                    question.Options.Add(option); // Add option to the question
                }
            }

            _context.Questions.Add(question);
            await _context.SaveChangesAsync();
            return RedirectToAction("Index"); // Redirect to the questions list after saving
        }

        return View(question); // If validation fails, return to the same view
    }

    // GET: SurveyApp/Edit/5
    [HttpGet]
    [Authorize(Permissions.SurveyApp.Edit)] // Check permission
    public async Task<IActionResult> Edit(int id)
    {
        var question = await _context.Questions
            .Include(q => q.Options)
            .FirstOrDefaultAsync(m => m.Id == id);

        if (question == null)
        {
            return NotFound();
        }

        return View(question);
    }

    // POST: SurveyApp/Edit/5
    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Permissions.SurveyApp.Edit)] // Check permission
    public async Task<IActionResult> Edit(int id, Question question, string[] options)
    {
        if (id != question.Id)
        {
            return NotFound();
        }

        if (ModelState.IsValid)
        {
            question.Options.Clear();
            foreach (var optionText in options)
            {
                if (!string.IsNullOrWhiteSpace(optionText))
                {
                    var option = new Option { Text = optionText };
                    question.Options.Add(option);
                }
            }

            try
            {
                _context.Update(question);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!QuestionExists(question.Id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }
            return RedirectToAction("Index");
        }

        return View(question);
    }

    // GET: SurveyApp/Delete/5
    [HttpGet]
    [Authorize(Permissions.SurveyApp.Delete)] // Check permission
    public async Task<IActionResult> Delete(int id)
    {
        var question = await _context.Questions
            .Include(q => q.Options)
            .FirstOrDefaultAsync(m => m.Id == id);

        if (question == null)
        {
            return NotFound();
        }

        return View(question);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    [Authorize(Permissions.SurveyApp.Delete)] // Check permission
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var question = await _context.Questions
            .Include(q => q.Options)
            .FirstOrDefaultAsync(q => q.Id == id);

        if (question != null)
        {
            _context.Options.RemoveRange(question.Options);
            _context.Questions.Remove(question);
            await _context.SaveChangesAsync();
        }

        return RedirectToAction("Index");
    }

    // Action method for viewing all submissions by users
    [HttpGet]
    [Authorize(Permissions.SurveyApp.ViewAnswers)] // Check permission
    public async Task<IActionResult> ViewSubmissions()
    {
        var submissions = await _context.Answers
            .Include(a => a.Question)
            .Include(a => a.Option)
            .ToListAsync();

        return View(submissions); // Pass the list of submissions to the view
    }

    // Method to fetch responses for admin dashboard
    // View all responses from users
    [HttpGet]
    [Authorize(Permissions.SurveyApp.ViewAnswers)] // Check permission
    public async Task<IActionResult> ViewResponses()
    {
        var responses = await _context.Responses.ToListAsync();
        return View(responses);
    }

    [HttpGet]
    [Authorize(Permissions.SurveyApp.ViewCharts)] // Check permission
    public IActionResult ResponsesChart()
    {
        var responses = _context.Responses.ToList(); // Fetch the responses
        return View(responses);
    }

    private bool QuestionExists(int id)
    {
        return _context.Questions.Any(q => q.Id == id);
    }
}*/
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TestApp.Data;
using TestApp.Models;
using System.Linq;
using System.Threading.Tasks;
using TestApp.Constants;
using TestApp.Areas.Identity.Data;
using Azure;

namespace TestApp.Controllers
{
    [Authorize]
    public class SurveyAppController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<TestAppUser> _userManager;

        public SurveyAppController(ApplicationDbContext context, UserManager<TestAppUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // GET: SurveyApp/Dashboard
        public IActionResult Dashboard()
        {
            return View();
        }

        // GET: SurveyApp/Index
        [HttpGet]
        [Authorize(Permissions.SurveyApp.View)]
        public async Task<IActionResult> Index()
        {
            var questions = await _context.Questions.Include(q => q.Options).ToListAsync();
            return View(questions);
        }

        // GET: SurveyApp/Create
        [HttpGet]
        [Authorize(Permissions.SurveyApp.Create)]
        public IActionResult Create()
        {
            var model = new QuestionViewModel();
            return View(model);
        }

        // POST: SurveyApp/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Permissions.SurveyApp.Create)]
        public IActionResult Create(QuestionViewModel model)
        {
            if (ModelState.IsValid)
            {
                var question = new Question
                {
                    Text = model.Text,
                    Options = model.Options.Select(o => new Option
                    {
                        Text = o.Text,
                        Marks = o.Marks // Save custom marks
                    }).ToList()
                };

                _context.Questions.Add(question);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(model);
        }


        // GET: SurveyApp/Edit/5
        /* [HttpGet]
         [Authorize(Permissions.SurveyApp.Edit)]
         public async Task<IActionResult> Edit(int id)
         {
             var question = await _context.Questions.Include(q => q.Options).FirstOrDefaultAsync(m => m.Id == id);
             if (question == null) return NotFound();
             return View(question);
         }

         // POST: SurveyApp/Edit/5
         [HttpPost]
         [ValidateAntiForgeryToken]
         [Authorize(Permissions.SurveyApp.Edit)]
         public async Task<IActionResult> Edit(int id, Question question, string[] options)
         {
             if (id != question.Id) return NotFound();

             if (ModelState.IsValid)
             {
                 question.Options.Clear();
                 foreach (var optionText in options)
                 {
                     if (!string.IsNullOrWhiteSpace(optionText))
                     {
                         question.Options.Add(new Option { Text = optionText });
                     }
                 }

                 try
                 {
                     _context.Update(question);
                     await _context.SaveChangesAsync();
                 }
                 catch (DbUpdateConcurrencyException)
                 {
                     if (!_context.Questions.Any(e => e.Id == question.Id)) return NotFound();
                     else throw;
                 }
                 return RedirectToAction("Index");
             }
             return View(question);
         }*/
        [HttpGet]
        [Authorize(Permissions.SurveyApp.Edit)]
        public async Task<IActionResult> Edit(int id)
        {
            var question = await _context.Questions
                .Include(q => q.Options)
                .FirstOrDefaultAsync(q => q.Id == id);

            if (question == null)
            {
                return NotFound();
            }

            return View(question);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Permissions.SurveyApp.Edit)]
        public async Task<IActionResult> Edit(int id, Question question)
        {
            if (id != question.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                _context.Update(question);

                // Update each option’s marks
                foreach (var option in question.Options)
                {
                    _context.Entry(option).Property(o => o.Marks).IsModified = true;
                }

                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(question);
        }


        // GET: SurveyApp/Delete/5
        [HttpGet]
        [Authorize(Permissions.SurveyApp.Delete)]
        public async Task<IActionResult> Delete(int id)
        {
            var question = await _context.Questions.Include(q => q.Options).FirstOrDefaultAsync(m => m.Id == id);
            if (question == null) return NotFound();
            return View(question);
        }

        // POST: SurveyApp/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Permissions.SurveyApp.Delete)]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var question = await _context.Questions.Include(q => q.Options).FirstOrDefaultAsync(q => q.Id == id);
            if (question != null)
            {
                _context.Options.RemoveRange(question.Options);
                _context.Questions.Remove(question);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("Index");
        }

        // Action method for viewing all submissions by users
        [HttpGet]
        [Authorize(Permissions.SurveyApp.ViewAnswers)] // Check permission
        public async Task<IActionResult> ViewSubmissions()
        {
            var submissions = await _context.Answers
                .Include(a => a.Question)
                .Include(a => a.Option)
                .ToListAsync();

            return View(submissions); // Pass the list of submissions to the view
        }

        // Method to fetch responses for admin dashboard
        [HttpGet]
        [Authorize(Permissions.SurveyApp.ViewAnswers)] // Check permission
        public async Task<IActionResult> ViewResponses()
        {
            var responses = await _context.Responses.ToListAsync();
            return View(responses);
        }

        // GET: SurveyApp/ResponsesChart
        [HttpGet]
        [Authorize(Permissions.SurveyApp.ViewCharts)] // Check permission
        public IActionResult ResponsesChart()
        {
            var responses = _context.Responses.ToList(); // Fetch the responses
            return View(responses);
        }

        private bool QuestionExists(int id)
        {
            return _context.Questions.Any(e => e.Id == id);
        }

        [HttpGet]
        [Authorize(Permissions.SurveyApp.ViewAnswers)] // Adjust permission as needed
        public async Task<IActionResult> UserResponseSummary()
        {
            var responses = await _context.Responses
                .Include(r => r.Question) // Include Question navigation property
                .Include(r => r.SelectedOption) // Include SelectedOption navigation property
                .ToListAsync();

            // Group responses by employee and plant location
            var groupedResponses = responses
                .GroupBy(r => new { r.EmployeeName, r.PlantLocation })
                .Select(g => new UserResponseSummaryViewModel
                {
                    EmployeeName = g.Key.EmployeeName,
                    PlantLocation = g.Key.PlantLocation,
                    TotalQuestions = g.Select(r => r.QuestionId).Distinct().Count(),
                    TotalMarks = g.Sum(r => r.SelectedOption?.Marks ?? 0), // Sum of all option marks
                    TotalMarksSelected = g.Where(r => r.SelectedOptionId != 0).Sum(r => r.SelectedOption?.Marks ?? 0) // Only non-zero option IDs
                })
                .ToList();

            return View(groupedResponses); // Return the list of employee summaries
        }






    }
}



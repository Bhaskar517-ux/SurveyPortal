﻿/*using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using TestApp.Areas.Identity.Data;
using TestApp.Models;

public class AccountController : Controller
{
    private readonly SignInManager<TestAppUser> _signInManager;
    private readonly UserManager<TestAppUser> _userManager;
    

    public ILogger<AccountController> logger { get; }

    public AccountController(SignInManager<TestAppUser> signInManager, UserManager<TestAppUser> userManager)
    {
        _signInManager = signInManager;
        _userManager = userManager;
       
    } 
    [HttpGet]
    [AllowAnonymous]
    public IActionResult Login()
    {
        return View(); // Return the login view
    }

    [HttpPost]
    [AllowAnonymous]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model)
    {
        if (ModelState.IsValid)
        {
            var user = await _userManager.FindByEmailAsync(model.Email);
            if (user == null)
            {
                user = await _userManager.FindByNameAsync(model.Email);
            }

            if (user != null)
            {
                var result = await _signInManager.PasswordSignInAsync(user, model.Password, model.RememberMe, lockoutOnFailure: false);
                if (result.Succeeded)
                {
                    if (await _userManager.IsInRoleAsync(user, "SurveyApp"))
                    {
                        return RedirectToAction("Index", "SurveyApp");
                    }
                    return RedirectToAction("Index", "User"); // Redirect to user questions page
                }
                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
            }
        }

        return View(model); // Redisplay form with errors
    }

    [HttpGet]
    public IActionResult Register()
    {
        return View(); // Return the registration view
    }

    [HttpPost]
    [AllowAnonymous]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Register(RegisterViewModel model)
    {
        if (ModelState.IsValid)
        {
            var user = new TestAppUser { UserName = model.Email, Email = model.Email };
            var result = await _userManager.CreateAsync(user, model.Password);
            if (result.Succeeded)
            {
                // Optionally, add the user to a default role
                await _userManager.AddToRoleAsync(user, "User");
                return RedirectToAction("Index", "Home"); // Redirect to the home page or wherever you want
            }
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }
        }
        return View(model); // Return the view with errors
    }


    [HttpPost]
    [AllowAnonymous]
    public async Task<IActionResult> Logout()
    {
        await _signInManager.SignOutAsync();
        return RedirectToAction("Index", "Home"); // Redirect to home after logout
    }


  
}*/
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using TestApp.Areas.Identity.Data;
using TestApp.Models;
using TestApp.Services;

namespace TestApp.Controllers
{
    public class AccountController : Controller
    {
        private readonly SignInManager<TestAppUser> _signInManager;
        private readonly UserManager<TestAppUser> _userManager;
        private readonly LdapService _ldapService;
        private readonly ILogger<AccountController> _logger;

        public AccountController(SignInManager<TestAppUser> signInManager, UserManager<TestAppUser> userManager, LdapService ldapService, ILogger<AccountController> logger)
        {
            _signInManager = signInManager;
            _userManager = userManager;
            _ldapService = ldapService;
            _logger = logger;
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult Login() => View();

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (ModelState.IsValid)
            {
                var ldapAuthenticated = _ldapService.Authenticate(model.Username, model.Password);

                if (ldapAuthenticated)
                {
                    var user = await _userManager.FindByNameAsync(model.Username);
                    if (user == null)
                    {
                        user = new TestAppUser { UserName = model.Username, Email = $"{model.Username}@{_ldapService._ldapSettings.Domain}" };
                        var createResult = await _userManager.CreateAsync(user);
                        if (!createResult.Succeeded)
                        {
                            foreach (var error in createResult.Errors)
                            {
                                ModelState.AddModelError(string.Empty, error.Description);
                            }
                            return View(model);
                        }
                    }

                    await _signInManager.SignInAsync(user, isPersistent: model.RememberMe);
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Invalid LDAP login attempt.");
                }
            }

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }
    }
}




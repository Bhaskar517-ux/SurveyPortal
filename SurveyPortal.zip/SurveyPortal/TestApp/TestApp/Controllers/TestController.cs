﻿/*using Microsoft.AspNetCore.Mvc;

namespace TestApp.Controllers
{
    public class TestController : Controller
    {
        public IActionResult Index()
        {
            return Content("Test Page"); // This returns plain text for simplicity
        }
    }
}
*/
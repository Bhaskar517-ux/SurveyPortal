﻿/*using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TestApp.Areas.Identity.Data;
using TestApp.Data;
using TestApp.Models;
using TestApp.ViewModels;

[Route("User")]
//[Authorize(Roles = "User")]
public class UserController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<TestAppUser> _userManager;

    public UserController(ApplicationDbContext context, UserManager<TestAppUser> userManager)
    {
        _context = context;
        _userManager = userManager;
    }

    [HttpGet("ViewQuestions")]
    public async Task<IActionResult> ViewQuestions(UserSubmissionViewModel model)
    {
        var questions = await _context.Questions
                                      .Include(q => q.Options) // Make sure to include options if any
                                      .ToListAsync();

        if (questions == null || !questions.Any())
        {
            ViewBag.Message = "No questions available.";
        }

        return View(questions); // Pass questions to the view
    }


    *//* public async Task<IActionResult> SubmitAnswer(UserSubmissionViewModel model)
     {
         // Log the incoming model values
         Console.WriteLine($"QuestionId: {model.QuestionId}, SelectedOptionId: {model.SelectedOptionId}");

         // Ensure you validate your model and save it to the database
         if (ModelState.IsValid)
         {
             var answer = new Answer
             {
                 QuestionId = model.QuestionId,
                 OptionId = model.SelectedOptionId,
                 // Add other necessary fields
             };

             // Check if the OptionId exists before saving
             var optionExists = await _context.Options.AnyAsync(o => o.Id == model.SelectedOptionId);
             if (!optionExists)
             {
                 ModelState.AddModelError("SelectedOptionId", "The selected option does not exist.");
                 return View(model); // Return the view with an error
             }

             _context.Answers.Add(answer);
             await _context.SaveChangesAsync(); // Attempt to save to the database

             return RedirectToAction("Success");
         }

         return View(model);
     }*//*
    [HttpPost]
    public ActionResult SubmitResponse(Response response)
    {
        if (ModelState.IsValid)
        {
            // Set additional properties
            response.ResponseDate = DateTime.Now; // Set the current date/time

            // Save to database
            _context.Responses.Add(response);
            _context.SaveChanges();

            // Redirect to a success page or show a message
            return RedirectToAction("Success");
        }

        // If we got this far, something failed; redisplay the form
        return View(response);
    }

    public ActionResult Success()
    {
        return View();
    }
    *//* [Route("SubmitAnswer")]
     [HttpPost]
     public IActionResult SubmitAnswer(UserSubmissionViewModel model)
     {
         // Your existing logic
         return RedirectToAction("Success");
     }*//*

}


*/
/*using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;
using TestApp.Data;
using TestApp.Models;

namespace TestApp.Controllers
{
    [Route("User")]
    public class UserController : Controller
    {
        private readonly ApplicationDbContext _context;

        public UserController(ApplicationDbContext context)
        {
            _context = context;
        }
        [HttpGet("ViewQuestions")]
        public async Task<IActionResult> ViewQuestions()
        {
            var questions = await _context.Questions
                                          .Include(q => q.Options)  // Include the options
                                          .ToListAsync();

            if (questions == null || !questions.Any())
            {
                ViewBag.Message = "No questions available.";
                return View();
            }

            // Pass the questions list to the view
            return View(questions);
        }


        [HttpPost("SubmitResponse")]
        public async Task<IActionResult> SubmitResponse(int[] SelectedOptionId, string EmployeeName, string PlantLocation, DateTime ResponseDate)
        {
            if (SelectedOptionId == null || !SelectedOptionId.Any())
            {
                // Handle error when no options are selected
                ModelState.AddModelError("", "Please select at least one option.");
                return View();
            }

            for (int i = 0; i < SelectedOptionId.Length; i++)
            {
                var selectedOptionId = SelectedOptionId[i];

                // Find the selected option
                var option = await _context.Options.FirstOrDefaultAsync(o => o.Id == selectedOptionId);
                if (option != null)
                {
                    // Increment the votes for the selected option
                    option.Votes += 1;

                    // Create a new response entry for the user
                    var response = new Response
                    {
                        QuestionId = option.QuestionId,
                        SelectedOptionId = option.Id,
                        EmployeeName = EmployeeName,
                        PlantLocation = PlantLocation,
                        ResponseDate = ResponseDate
                    };

                    _context.Responses.Add(response);
                }
            }

            // Save the changes to the database (both votes and responses)
            await _context.SaveChangesAsync();

            return RedirectToAction("Success");
        }

        public IActionResult Success()
        {
            return View();
        }
    }
}*/
// Hnadle user data view quetions
/*using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;
using TestApp.Data;
using TestApp.Models;

namespace TestApp.Controllers
{
    [Route("User")]
    public class UserController : Controller
    {
        private readonly ApplicationDbContext _context;

        public UserController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("ViewQuestions")]
        public async Task<IActionResult> ViewQuestions()
        {
            var questions = await _context.Questions
                                          .Include(q => q.Options)  // Include the options
                                          .ToListAsync();

            if (questions == null || !questions.Any())
            {
                ViewBag.Message = "No questions available.";
                return View();
            }

            // Pass the questions list to the view
            return View(questions);
        }
        *//* [HttpPost]
         public async Task<IActionResult> SubmitResponse(Dictionary<int, int> selectedOptionId, string employeeName, string plantLocation, DateTime responseDate)
         {
             if (selectedOptionId == null || !selectedOptionId.Any())
             {
                 // Handle error when no options are selected
                 ModelState.AddModelError("", "Please select at least one option.");
                 return View();
             }

             foreach (var entry in selectedOptionId)
             {
                 var questionId = entry.Key;  // The question ID
                 var optionId = entry.Value;  // The selected option ID

                 // Fetch the question and selected option from the database
                 var question = await _context.Questions.FirstOrDefaultAsync(q => q.Id == questionId);
                 var selectedOption = await _context.Options.FirstOrDefaultAsync(o => o.Id == optionId);

                 if (question != null && selectedOption != null)
                 {
                     // Create a new response entry for the user
                     var response = new Response
                     {
                         QuestionId = question.Id,
                         SelectedOptionId = selectedOption.Id,
                         QuestionText = question.Text,         // Store question text
                         SelectedOptionText = selectedOption.Text, // Store selected option text
                         Marks = selectedOption.Marks,          // Store marks of selected option
                         EmployeeName = employeeName,
                         PlantLocation = plantLocation,
                         ResponseDate = responseDate
                     };

                     _context.Responses.Add(response);
                 }
             }

             // Save the changes to the database (responses)
             await _context.SaveChangesAsync();

             return RedirectToAction("Success");
         }*//*
        [HttpPost]
        public async Task<IActionResult> SubmitResponse(Dictionary<int, int> selectedOptionId, string employeeName, string plantLocation, DateTime responseDate)
        {
            if (selectedOptionId == null || !selectedOptionId.Any())
            {
                // Handle error when no options are selected
                ModelState.AddModelError("", "Please select at least one option.");
                return View();
            }

            foreach (var entry in selectedOptionId)
            {
                var questionId = entry.Key;  // The question ID
                var optionId = entry.Value;  // The selected option ID

                // Fetch the question and its options from the database
                var question = await _context.Questions.Include(q => q.Options).FirstOrDefaultAsync(q => q.Id == questionId);

                if (question != null)
                {
                    // Find the selected option and calculate the marks based on the position of the option
                    var selectedOption = question.Options.FirstOrDefault(o => o.Id == optionId);
                    var options = question.Options.OrderBy(o => o.Id).ToList(); // Ensure options are ordered
                    int marks = options.FindIndex(o => o.Id == selectedOption.Id); // Get the index of the selected option

                    if (selectedOption != null)
                    {
                        // Create a new response entry for the user
                        var response = new Response
                        {
                            QuestionId = question.Id,
                            SelectedOptionId = selectedOption.Id,
                            QuestionText = question.Text,         // Store question text
                            SelectedOptionText = selectedOption.Text, // Store selected option text
                            Marks = marks,                       // Store marks based on the option index
                            EmployeeName = employeeName,
                            PlantLocation = plantLocation,
                            ResponseDate = responseDate
                        };

                        _context.Responses.Add(response);
                    }
                }
            }

            // Save the changes to the database (responses)
            await _context.SaveChangesAsync();

            return RedirectToAction("Success");
        }




        public IActionResult Success()
        {
            return View();
        }
    }
}
*/
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TestApp.Data;
using TestApp.Models;

namespace TestApp.Controllers
{
    [Route("User")]
    public class UserController : Controller
    {
        private readonly ApplicationDbContext _context;

        public UserController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("ViewQuestions")]
        public async Task<IActionResult> ViewQuestions()
        {
            var questions = await _context.Questions
                                          .Include(q => q.Options)  // Include the options
                                          .ToListAsync();

            if (questions == null || !questions.Any())
            {
                ViewBag.Message = "No questions available.";
                return View();
            }

            // Pass the questions list to the view
            return View(questions);
        }

        [HttpPost]
        public async Task<IActionResult> SubmitResponse(Dictionary<int, int> selectedOptionId, string employeeName, string plantLocation, DateTime responseDate)
        {
            if (selectedOptionId == null || !selectedOptionId.Any())
            {
                // Handle error when no options are selected
                ModelState.AddModelError("", "Please select at least one option.");
                return View();
            }

            foreach (var entry in selectedOptionId)
            {
                var questionId = entry.Key;  // The question ID
                var optionId = entry.Value;  // The selected option ID

                // Fetch the question and its options from the database
                var question = await _context.Questions.Include(q => q.Options).FirstOrDefaultAsync(q => q.Id == questionId);

                if (question != null)
                {
                    // Find the selected option using the provided option ID
                    var selectedOption = question.Options.FirstOrDefault(o => o.Id == optionId);

                    if (selectedOption != null)
                    {
                        // Create a new response entry for the user
                        var response = new Response
                        {
                            QuestionId = question.Id,
                            SelectedOptionId = selectedOption.Id,
                            QuestionText = question.Text,         // Store question text
                            SelectedOptionText = selectedOption.Text, // Store selected option text
                            Marks = selectedOption.Marks,          // Store marks from the selected option directly
                            EmployeeName = employeeName,
                            PlantLocation = plantLocation,
                            ResponseDate = responseDate
                        };

                        _context.Responses.Add(response);
                    }
                }
            }

            // Save the changes to the database (responses)
            await _context.SaveChangesAsync();

            return RedirectToAction("Success");
        }

        public IActionResult Success()
        {
            return View();
        }
    }
}




﻿using Microsoft.AspNetCore.Authorization;
using System.Linq;
using System.Threading.Tasks;


namespace TestApp.Permission
{
    internal class PermissionAuthorizationHandler : AuthorizationHandler<PermissionRequirement>
    {
        public PermissionAuthorizationHandler()
        {
        }

        protected override async Task HandleRequirementAsync(AuthorizationHandlerContext context, PermissionRequirement requirement)
        {
            if (context.User == null)
            {
                return;
            }

            var permissions = context.User.Claims.Where(x => x.Type == "Permission" &&
                                                             x.Value == requirement.Permission &&
                                                             x.Issuer == "LOCAL AUTHORITY");
            if (permissions.Any())
            {
                context.Succeed(requirement);
            }

            // Explicitly await something to avoid the warning
            await Task.CompletedTask;
        }
    }
}


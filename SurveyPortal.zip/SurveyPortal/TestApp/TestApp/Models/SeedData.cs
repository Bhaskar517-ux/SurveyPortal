﻿/*namespace TestApp.Models
{
    public class SeedData
    {
    }
}
*/
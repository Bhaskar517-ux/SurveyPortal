﻿using System.ComponentModel.DataAnnotations;

namespace TestApp.Models
{
    public class QuestionViewModel
    {
        public string Text { get; set; }
        public List<OptionViewModel> Options { get; set; } = new List<OptionViewModel>
    {
        new OptionViewModel(),
        new OptionViewModel(),
        new OptionViewModel()
    };
    }

    public class OptionViewModel
    {
        public int Id { get; set; }
        public string Text { get; set; }
        [Range(-10, 10, ErrorMessage = "Marks must be between -10 and 10.")]
        public int Marks { get; set; }
    }
}
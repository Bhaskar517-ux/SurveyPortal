﻿//using Microsoft.CodeAnalysis.Options;
//using System.Collections.Generic;

//namespace TestApp.Models
//{
//    public class Question
//    {
//        public int Id { get; set; }
//        public string Text { get; set; }
//        public List<Option> Options { get; set; } = new List<Option>();
//        //public ICollection<Option> Options { get; set; } // A Question can have multiple Options
//        //public ICollection<Answer> Answers { get; set; } // A Question can have multiple Answers
//    }
//}
using System.Collections.Generic;

namespace TestApp.Models
{
    public class Question
    {
        public int Id { get; set; }
        public string Text { get; set; }

        // Navigation property for related options
        public List<Option> Options { get; set; } = new List<Option>();

        // Navigation property for answers
        public ICollection<Answer> Answers { get; set; } = new List<Answer>();
    }
}

﻿namespace TestApp.Models
{
    public class UserResponseSummaryViewModel
    {
        public string EmployeeName { get; set; }
        public string PlantLocation { get; set; }
        public int TotalQuestions { get; set; }
        public int TotalMarks { get; set; }
        public int TotalMarksSelected { get; set; }
    }
}

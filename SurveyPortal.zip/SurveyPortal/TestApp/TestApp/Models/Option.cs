﻿//namespace TestApp.Models
//{
//    public class Option
//    {
//        public int Id { get; set; }
//        public string Text { get; set; }
//        public int Votes { get; set; }
//        public object Question { get; internal set; }
//        //public int QuestionId { get; set; }
//        //public Question Question { get; set; } // Navigation property to Question
//    }
//}
using System.ComponentModel.DataAnnotations;

namespace TestApp.Models
{
    public class Option
    {
        public int Id { get; set; }
        public string Text { get; set; }
        public int Votes { get; set; }
        [Range(-10, 10)]
        public int Marks { get; set; } // This stores the marks for the option
        // Foreign key to the Question
        public int QuestionId { get; set; }
        public Question Question { get; set; } // Navigation property to Question
    }
}

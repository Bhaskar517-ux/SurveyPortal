﻿namespace TestApp.Models
{
    public class UserResponse
    {
        public int Id { get; set; }
        public string EmployeeName { get; set; }
        public string PlantLocation { get; set; }
        public DateTime Date { get; set; }
        public string SelectedOption { get; set; }
        public int QuestionId { get; set; }
    }

}

﻿using System;
using System.Collections.Generic;
using TestApp.Models;

namespace TestApp.ViewModels
{
    public class UserSubmissionViewModel
    {
        public int QuestionId { get; set; }
        public string QuestionText { get; set; }
        public List<Option> Options { get; set; }  // For displaying options
        public int SelectedOptionId { get; set; } // For storing the user's selected option
        public string EmployeeName { get; set; } // For collecting the employee's name
        public string PlantLocation { get; set; } // For collecting the plant location
        public DateTime Date { get; set; } // Submission date
    }

   /* public class Option
    {
        public int Id { get; set; }
        public string Text { get; set; }
    }*/
}

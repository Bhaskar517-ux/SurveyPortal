﻿/*namespace TestApp.Models
{
    public class Answer
    {
        public int Id { get; set; }
        public int QuestionId { get; set; }
        public int OptionId { get; set; }
    }
}
*/

namespace TestApp.Models
{
    public class Answer
    {
        public int Id { get; set; }
        public int QuestionId { get; set; }
        public int OptionId { get; set; }

        // Navigation properties
        public Question Question { get; set; } // Navigation property to Question
        public Option Option { get; set; } // Navigation property to Option
        public string EmployeeName { get; internal set; }
        public string PlantLocation { get; internal set; }
        public DateTime Date { get; internal set; }
        public int SelectedOptionId { get; internal set; }
        // Add a score field
        public int Score { get; set; }
    }
}

﻿namespace TestApp.Models
{
public class Response
{
    public int Id { get; set; }
    public int UserId { get; set; } // Assuming you have user authentication
    public int QuestionId { get; set; } // Foreign key to the Question
    public string QuestionText { get; set; } // Storing the actual question text
    public int SelectedOptionId { get; set; } // Foreign key to the selected Option
    public string SelectedOptionText { get; set; } // Storing the selected option text
    public string EmployeeName { get; set; }
    public string PlantLocation { get; set; }
    public DateTime ResponseDate { get; set; }
    public int Marks { get; set; } // Storing the marks associated with the selected option

        // Navigation properties
        public Question Question { get; set; }
        public Option SelectedOption { get; set; }
    }
}
﻿namespace TestApp.Models
{
    public class UserData
    {
        public int Id { get; set; }
        public string UserId { get; set; }
        public string Data { get; set; }
        public bool IsAdmin { get; set; }
    }
}

﻿namespace TestApp.Constants
{
    public enum Roles
    {
        SuperAdmin,
        Admin,
        Basic
    }
}

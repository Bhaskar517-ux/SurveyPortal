﻿namespace TestApp.Constants
{
    public static class Permissions
    {
        public static List<string> GeneratePermissionsForModule(string module)
        {
            return new List<string>()
            {
                $"Permissions.{module}.Create",
                $"Permissions.{module}.View",
                $"Permissions.{module}.Edit",
                $"Permissions.{module}.Delete",
                $"Permissions.{module}.ViewAnswers",  // New permission
                $"Permissions.{module}.ViewCharts"    // New permission
            };
        }

        public static class SurveyApp
        {
            public const string View = "Permissions.SurveyApp.View";
            public const string Create = "Permissions.SurveyApp.Create";
            public const string Edit = "Permissions.SurveyApp.Edit";
            public const string Delete = "Permissions.SurveyApp.Delete";
            public const string Details = "Permissions.SurveyApp.Details";
            public const string ViewAnswers = "Permissions.SurveyApp.ViewAnswers"; // New permission
            public const string ViewCharts = "Permissions.SurveyApp.ViewCharts";   // New permission
        }
    }
}

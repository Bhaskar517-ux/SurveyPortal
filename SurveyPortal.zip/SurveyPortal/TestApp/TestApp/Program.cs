/*using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using TestApp.Data;
using TestApp.Areas.Identity.Data;
using Microsoft.AspNetCore.Identity.UI.Services;

namespace TestApp
{
    public class Program
    {
        //public static void Main(string[] args)
        //{
        //    var host = CreateHostBuilder(args).Build();

        //    using (var scope = host.Services.CreateScope())
        //    {
        //        var services = scope.ServiceProvider;
        //        try
        //        {
        //            // Seed roles and the admin user
        //            RoleInitializer.SeedRoles(services).Wait();
        //        }
        //        catch (Exception ex)
        //        {
        //            var logger = services.GetRequiredService<ILogger<Program>>();
        //            logger.LogError(ex, "An error occurred while seeding roles.");
        //        }
        //    }

        //    host.Run();
        //}

        public static IHostBuilder CreateHostBuilder(string[] args)
        {
            return Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.ConfigureServices((context, services) =>
                    {
                        var configuration = context.Configuration;

                        // Setup database context
                        services.AddDbContext<ApplicationDbContext>(options =>
                            options.UseSqlServer(configuration.GetConnectionString("DefaultConnection")));



                        // Setup Identity services
                        services.AddIdentity<TestAppUser, IdentityRole>(options =>
                        {
                            options.SignIn.RequireConfirmedAccount = false; // Set to true if you want email confirmation
                            options.Password.RequireDigit = true;
                            options.Password.RequireLowercase = true;
                            options.Password.RequireNonAlphanumeric = true;
                            options.Password.RequireUppercase = true;
                            options.Password.RequiredLength = 8;
                            options.Password.RequiredUniqueChars = 1;
                        })
                           .AddEntityFrameworkStores<ApplicationDbContext>()
                           .AddDefaultTokenProviders();
                        // Register the EmailSender as IEmailSender
                        services.AddTransient<IEmailSender, EmailSender>();

                        // Add controllers and Razor Pages
                        services.AddControllersWithViews();
                        services.AddRazorPages();
                    });

                    webBuilder.Configure((context, app) =>
                    {
                        var env = context.HostingEnvironment;

                        if (env.IsDevelopment())
                        {
                            app.UseDeveloperExceptionPage();
                        }
                        else
                        {
                            app.UseExceptionHandler("/Home/Error");
                            app.UseHsts();
                        }


                        app.UseHttpsRedirection();
                        app.UseStaticFiles();
                        app.UseRouting();
                        app.UseAuthentication();
                        app.UseAuthorization();

                        app.UseEndpoints(endpoints =>
                        {

                            endpoints.MapControllerRoute(
                                name: "default",
                                pattern: "{controller=Home}/{action=Index}/{id?}");
                            endpoints.MapRazorPages();
                           
                        });

                        // Seed roles and admin user on startup
                        *//*using var scope = app.ApplicationServices.CreateScope();
                        var services = scope.ServiceProvider;
                        RoleInitializer.SeedRoles(services).Wait();*//*
                    });
                });
        }
    }
}
*/

/*using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using TestApp.Data;
using TestApp.Areas.Identity.Data;
using Microsoft.AspNetCore.Identity.UI.Services;

namespace TestApp
{
    public class Program
    {
        public static async Task Main(string[] args)
        {
            var host = CreateHostBuilder(args).Build();

            using (var scope = host.Services.CreateScope())
            {
                var services = scope.ServiceProvider;
                try
                {
                    // Seed roles and the admin user
                    await RoleInitializer.SeedRoles(services);
                }
                catch (Exception ex)
                {
                    var logger = services.GetRequiredService<ILogger<Program>>();
                    logger.LogError(ex, "An error occurred seeding the DB.");
                }
            }

            await host.RunAsync();
        }


        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.ConfigureServices((context, services) =>
                    {
                        var configuration = context.Configuration;

                        // Setup database context
                        services.AddDbContext<ApplicationDbContext>(options =>
                            options.UseSqlServer(configuration.GetConnectionString("DefaultConnection")));

                        // Setup Identity services
                        services.AddIdentity<TestAppUser, IdentityRole>(options =>
                        {
                            options.SignIn.RequireConfirmedAccount = false; // Set to true if you want email confirmation
                            options.Password.RequireDigit = true;
                            options.Password.RequireLowercase = true;
                            options.Password.RequireNonAlphanumeric = true;
                            options.Password.RequireUppercase = true;
                            options.Password.RequiredLength = 8;
                            options.Password.RequiredUniqueChars = 1;
                        })
                        .AddEntityFrameworkStores<ApplicationDbContext>()
                        .AddDefaultTokenProviders();

                        // Register the EmailSender as IEmailSender
                        services.AddTransient<IEmailSender, EmailSender>();

                        // Add authorization and policies
                        ConfigureServices(services);
                    });

                    webBuilder.Configure((context, app) =>
                    {
                        var env = context.HostingEnvironment;

                        if (env.IsDevelopment())
                        {
                            app.UseDeveloperExceptionPage();
                        }
                        else
                        {
                            app.UseExceptionHandler("/Home/Error");
                            app.UseHsts();
                        }

                        app.UseHttpsRedirection();
                        app.UseStaticFiles();
                        app.UseRouting();
                        app.UseAuthentication();
                        app.UseAuthorization();

                        app.UseEndpoints(endpoints =>
                        {
                            endpoints.MapControllerRoute(
                                name: "default",
                                pattern: "{controller=Home}/{action=Index}/{id?}");
                            endpoints.MapRazorPages();
                        });


                        // Seed roles and admin user on startup
                        using var scope = app.ApplicationServices.CreateScope();
                        var services = scope.ServiceProvider;
                        RoleInitializer.SeedRoles(services).Wait();
                    });
                });

        // Adding the ConfigureServices method as required
        public static void ConfigureServices(IServiceCollection services)
        {
            services.AddIdentity<IdentityUser, IdentityRole>()
                .AddEntityFrameworkStores<ApplicationDbContext>()
                .AddDefaultTokenProviders();

            services.ConfigureApplicationCookie(options =>
            {
                options.AccessDeniedPath = "/Account/AccessDenied"; // Set the AccessDenied path
                options.LoginPath = "/Account/Login"; // Set the login path
            });

            // Add your authorization policies here
            services.AddAuthorization(options =>
            {
                options.AddPolicy("AdminOnly", policy => policy.RequireRole("Admin"));
                options.AddPolicy("UserOnly", policy => policy.RequireRole("User"));
            });

            services.AddControllersWithViews();
        }
    }*/
//}
/*using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using TestApp.Data;
using TestApp.Areas.Identity.Data;
using Microsoft.AspNetCore.Identity.UI.Services;
using TestApp.Constants;
using TestApp.Seeds;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("ApplicationDbContext")
    ?? throw new InvalidOperationException("Connection string 'ApplicationDbContext' not found.")));

builder.Services.AddDefaultIdentity<TestAppUser>()
    .AddRoles<IdentityRole>()
    .AddEntityFrameworkStores<ApplicationDbContext>();

builder.Services.AddControllersWithViews();


builder.Services.Configure<IdentityOptions>(options =>
{
    // Password settings
    options.Password.RequireDigit = true;
    options.Password.RequireLowercase = true;
    options.Password.RequireNonAlphanumeric = false;
    options.Password.RequireUppercase = true;
    options.Password.RequiredLength = 6;
});

// Add Authorization policies for the SuperAdmin role and BagFilter permissions
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("SuperAdminPolicy", policy => policy.RequireRole("SuperAdmin"));

    // Define authorization policies for SurveyApp permissions
    options.AddPolicy(Permissions.SurveyApp.View, policy => policy.RequireClaim("Permission", Permissions.SurveyApp.View));
    options.AddPolicy(Permissions.SurveyApp.Create, policy => policy.RequireClaim("Permission", Permissions.SurveyApp.Create));
    options.AddPolicy(Permissions.SurveyApp.Edit, policy => policy.RequireClaim("Permission", Permissions.SurveyApp.Edit));
    options.AddPolicy(Permissions.SurveyApp.Delete, policy => policy.RequireClaim("Permission", Permissions.SurveyApp.Delete));
    options.AddPolicy(Permissions.SurveyApp.Details, policy => policy.RequireClaim("Permission", Permissions.SurveyApp.Details));

    // New policies for additional permissions
    options.AddPolicy(Permissions.SurveyApp.ViewAnswers, policy => policy.RequireClaim("Permission", Permissions.SurveyApp.ViewAnswers));
    options.AddPolicy(Permissions.SurveyApp.ViewCharts, policy => policy.RequireClaim("Permission", Permissions.SurveyApp.ViewCharts));
});


var app = builder.Build();

// Ensure the database is created and seeded
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var userManager = services.GetRequiredService<UserManager<TestAppUser>>();
    var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();

    // Seed roles
    await DefaultRoles.SeedAsync(userManager, roleManager);
    // Seed users
    await DefaultUsers.SeedBasicUserAsync(userManager, roleManager);
    await DefaultUsers.SeedSuperAdminAsync(userManager, roleManager);
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
// Enable detailed error logging
app.UseDeveloperExceptionPage();
app.UseStatusCodePages();
app.UseAuthentication();
app.UseAuthorization();

#pragma warning disable

app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "default",
        pattern: "{controller=Home}/{action=Index}/{id?}");
    endpoints.MapRazorPages();
});
app.MapRazorPages(); // Ensure Razor Pages are mapped

app.Run();*/

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using TestApp.Data;
using TestApp.Areas.Identity.Data;
using TestApp.Constants;
using TestApp.Seeds;
using TestApp.Services;
using TestApp.Models; // Add LDAP service namespace

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("ApplicationDbContext")
    ?? throw new InvalidOperationException("Connection string 'ApplicationDbContext' not found.")));

// Identity services
builder.Services.AddDefaultIdentity<TestAppUser>()
    .AddRoles<IdentityRole>()
    .AddEntityFrameworkStores<ApplicationDbContext>();


builder.Services.AddControllersWithViews();

// Configure Identity options
builder.Services.Configure<IdentityOptions>(options =>
{
    options.Password.RequireDigit = true;
    options.Password.RequireLowercase = true;
    options.Password.RequireNonAlphanumeric = false;
    //options.Password.RequireUppercase = true;
    options.Password.RequiredLength = 6;
});
builder.Services.Configure<LdapSettings>(builder.Configuration.GetSection("LdapSettings"));
builder.Services.AddScoped<LdapService>();

// Add Authorization policies
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("SuperAdminPolicy", policy => policy.RequireRole("SuperAdmin"));

    // Define authorization policies for SurveyApp permissions
    options.AddPolicy(Permissions.SurveyApp.View, policy => policy.RequireClaim("Permission", Permissions.SurveyApp.View));
    options.AddPolicy(Permissions.SurveyApp.Create, policy => policy.RequireClaim("Permission", Permissions.SurveyApp.Create));
    options.AddPolicy(Permissions.SurveyApp.Edit, policy => policy.RequireClaim("Permission", Permissions.SurveyApp.Edit));
    options.AddPolicy(Permissions.SurveyApp.Delete, policy => policy.RequireClaim("Permission", Permissions.SurveyApp.Delete));
    options.AddPolicy(Permissions.SurveyApp.Details, policy => policy.RequireClaim("Permission", Permissions.SurveyApp.Details));

    // New policies for additional permissions
    options.AddPolicy(Permissions.SurveyApp.ViewAnswers, policy => policy.RequireClaim("Permission", Permissions.SurveyApp.ViewAnswers));
    options.AddPolicy(Permissions.SurveyApp.ViewCharts, policy => policy.RequireClaim("Permission", Permissions.SurveyApp.ViewCharts));
});

// Register the LDAP service
builder.Services.AddScoped<LdapService>();

var app = builder.Build();

// Seed roles and users on startup
using (var scope = app.Services.CreateScope())
{
    var services = scope.ServiceProvider;
    var userManager = services.GetRequiredService<UserManager<TestAppUser>>();
    var roleManager = services.GetRequiredService<RoleManager<IdentityRole>>();

    // Seed roles
    await DefaultRoles.SeedAsync(userManager, roleManager);
    // Seed users
    await DefaultUsers.SeedBasicUserAsync(userManager, roleManager);
    await DefaultUsers.SeedSuperAdminAsync(userManager, roleManager);
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}
else
{
    // Enable detailed error logging in development
    app.UseDeveloperExceptionPage();
    app.UseStatusCodePages();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

#pragma warning disable
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllerRoute(
        name: "default",
        pattern: "{controller=Home}/{action=Index}/{id?}");
    endpoints.MapRazorPages();
});

app.Run();

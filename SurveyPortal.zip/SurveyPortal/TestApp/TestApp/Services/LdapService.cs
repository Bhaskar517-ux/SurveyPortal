﻿using System.DirectoryServices.Protocols;
using System.Net;
using Microsoft.Extensions.Options;
using Microsoft.Extensions.Logging;
using TestApp.Models;

namespace TestApp.Services
{
    public class LdapService
    {
        public readonly LdapSettings _ldapSettings;
        private readonly ILogger<LdapService> _logger;

        public LdapService(IOptions<LdapSettings> ldapSettings, ILogger<LdapService> logger)
        {
            _ldapSettings = ldapSettings.Value;
            _logger = logger;
        }

        public bool Authenticate(string username, string password)
        {
            try
            {
                var credentials = new NetworkCredential($"{username}@{_ldapSettings.Domain}", password);
                var serverId = new LdapDirectoryIdentifier(_ldapSettings.LdapServer);

                using (var connection = new LdapConnection(serverId))
                {
                    connection.Credential = credentials;
                    connection.AuthType = AuthType.Negotiate;  // Use Negotiate for secure authentication
                    connection.Bind();
                    _logger.LogInformation("LDAP authentication successful for user: {Username}", username);
                    return true;
                }
            }
            catch (LdapException ex)
            {
                _logger.LogWarning("LDAP authentication failed for user: {Username}. Error: {Error}", username, ex.Message);
                return false;
            }
            catch (Exception ex)
            {
                _logger.LogError("Unexpected error during LDAP authentication for user: {Username}. Exception: {Exception}", username, ex);
                return false;
            }
        }
    }
}
